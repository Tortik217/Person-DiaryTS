export interface INote {
  id: string
  text: string
  completed: boolean
  date: string
}